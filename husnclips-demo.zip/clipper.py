import time

def process_clip(youtube_url):
    print(f"Processing: {youtube_url}")
    time.sleep(5)
    print(f"Finished processing: {youtube_url}")
    return f"Clip for {youtube_url} done!"