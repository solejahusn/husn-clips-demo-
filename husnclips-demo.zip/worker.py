from redis import Redis
from rq import Worker, Queue, Connection
import os
from dotenv import load_dotenv

load_dotenv()
redis_url = os.environ.get("REDIS_URL", "redis://localhost:6379")
conn = Redis.from_url(redis_url)

if __name__ == "__main__":
    with Connection(conn):
        worker = Worker(list(map(Queue, ["default"])))
        worker.work()